
#ifndef _UTILS_H
#define _UTILS_H

#include "paciente.h"
#include "lesao.h"

void associaLesaoPaciente(Paciente *pacs, int tamPacs, Lesao les);



#endif