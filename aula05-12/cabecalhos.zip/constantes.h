
#define MAX_TAM_ID 10
#define MAX_TAM_DIAG 100
#define MAX_TAM_REGIAO 100

#define MAX_TAM_NOME 100
#define SUS_TAM 20
#define MAX_TAM_LES 10

#define TRUE 1
#define FALSE 0
#define MAX_TAM_PACIENTES 100